package com.littlebee.geomonitor

import android.Manifest
import android.app.KeyguardManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.location.Address
import android.location.Geocoder
import android.location.Location
import android.os.BatteryManager
import android.os.Build
import android.os.Looper
import android.speech.tts.TextToSpeech
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.lifecycle.LifecycleService
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.Locale
import java.util.concurrent.Executors

class GeoMonitorService : LifecycleService(), TextToSpeech.OnInitListener {

    companion object {
        const val CHANNEL_ID = "geomonitor_channel"
        const val NOTIF_ID = 1001
        const val ACTION_UNLOCK_ATTEMPT_FAILED = "com.littlebee.geomonitor.ACTION_UNLOCK_FAILED"
        const val EXTRA_FAILED_COUNT = "extra_failed_count"
    }

    private lateinit var fusedClient: FusedLocationProviderClient
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val httpClient = OkHttpClient()
    private val bgExecutor = Executors.newSingleThreadExecutor()
    private var lastFailedUnlockStatus: String = "nihil"

    private val locationCallback = object : LocationCallback() {
        override fun onLocationResult(result: LocationResult) {
            val location = result.lastLocation ?: return
            handleNewLocation(location)
        }
    }

    override fun onCreate() {
        super.onCreate()
        fusedClient = LocationServices.getFusedLocationProviderClient(this)
        tts = TextToSpeech(this, this)
        createNotificationChannel()
        startForeground(NOTIF_ID, buildNotification("Memantau posisi perangkat..."))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)

        if (intent?.action == ACTION_UNLOCK_ATTEMPT_FAILED) {
            val count = intent.getIntExtra(EXTRA_FAILED_COUNT, 1)
            lastFailedUnlockStatus = describeFailedCount(count)
            bgExecutor.execute { capturePhotoOnFailedUnlock(count) }
            return START_STICKY
        }

        startLocationUpdates()
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        fusedClient.removeLocationUpdates(locationCallback)
        tts?.stop()
        tts?.shutdown()
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale("id", "ID")
            ttsReady = true
        }
    }

    // ---------- Lokasi ----------

    private fun startLocationUpdates() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED
        ) {
            return
        }

        val intervalMinutes = Prefs.getIntervalMinutes(this).coerceAtLeast(1)
        val intervalMillis = intervalMinutes * 60_000L

        val request = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, intervalMillis)
            .setMinUpdateIntervalMillis(intervalMillis / 2)
            .build()

        fusedClient.requestLocationUpdates(request, locationCallback, Looper.getMainLooper())
    }

    private fun handleNewLocation(location: Location) {
        val minDistance = Prefs.getMinDistanceMeters(this)

        if (!Prefs.hasLastLocation(this)) {
            Prefs.setLastLocation(this, location.latitude, location.longitude)
            return
        }

        val lastLoc = Location("last").apply {
            latitude = Prefs.getLastLat(this@GeoMonitorService)
            longitude = Prefs.getLastLon(this@GeoMonitorService)
        }

        val distance = lastLoc.distanceTo(location)
        if (distance < minDistance) {
            return
        }

        val bearing = lastLoc.bearingTo(location)
        val direction = bearingToDirection(bearing)

        Prefs.setLastLocation(this, location.latitude, location.longitude)

        bgExecutor.execute {
            processAndReport(location, distance, direction)
        }
    }

    private fun bearingToDirection(bearing: Float): String {
        val normalized = (bearing + 360) % 360
        val labels = arrayOf(
            "utara", "timur laut", "timur", "tenggara",
            "selatan", "barat daya", "barat", "barat laut"
        )
        val index = Math.round(normalized / 45f) % 8
        return labels[index]
    }

    // ---------- Proses data + kirim + ucapkan ----------

    private fun processAndReport(location: Location, distance: Float, direction: String) {
        val address = reverseGeocode(location.latitude, location.longitude)
        val weather = fetchWeather(location.latitude, location.longitude)
        val battery = getBatteryInfo()
        val keyguard = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        val screenLocked = keyguard.isKeyguardLocked
        val failedCount = Prefs.getFailedUnlockCount(this)
        val failedStatus = describeFailedCount(failedCount)

        val zoneInfo = evaluateTrustedZone(location)

        val sentence = buildString {
            if (zoneInfo.insideZone) {
                append("Perangkat berada dalam zona terpercaya")
                if (zoneInfo.nearestName != null) append(", dekat ${zoneInfo.nearestName}")
                append(". ")
            } else if (zoneInfo.nearestName != null) {
                val distanceKm = "%.2f".format(zoneInfo.distanceMeters / 1000f)
                append("Perangkat anda berada sejauh $distanceKm kilometer arah ${zoneInfo.directionFromTrusted} ")
                append("dari lokasi yang anda percaya, yaitu ${zoneInfo.nearestName}. ")
            } else {
                append("Belum ada alamat terpercaya yang diatur. ")
            }

            append("Posisi koordinat ${"%.5f".format(location.latitude)}, ${"%.5f".format(location.longitude)}. ")
            if (location.hasAltitude()) {
                append("Saat ini berada di ketinggian ${location.altitude.toInt()} meter. ")
            }
            append("Kondisi sekitar ${weather.condition}, kecepatan angin ${weather.windSpeed} kilometer per jam, ")
            append("kelembaban ${weather.humidity} persen. ")
            append("Alamat perkiraan: $address. ")
            append("Baterai perangkat ${battery.level} persen, suhu perangkat ${battery.temperature} derajat celcius. ")
            append("Layar kunci saat ini ${if (screenLocked) "aktif" else "non aktif"}. ")
            append("Percobaan buka kunci ilegal $failedCount kali. ")
            append("Seluruh data terkini beserta posisi GPS telah dikirim ke server pribadi dan nomor WhatsApp anda.")
        }

        speak(sentence)
        sendToServer(location, distance, direction, address, weather, battery, screenLocked, failedCount, zoneInfo)
        sendWhatsApp(sentence)

        val notifSummary = if (zoneInfo.insideZone) {
            "Dalam zona terpercaya${if (zoneInfo.nearestName != null) " (${zoneInfo.nearestName})" else ""}"
        } else {
            "${"%.2f".format(zoneInfo.distanceMeters / 1000f)} km ke ${zoneInfo.directionFromTrusted} dari ${zoneInfo.nearestName ?: "-"}"
        }
        updateNotification(notifSummary)
    }

    private data class ZoneInfo(
        val insideZone: Boolean,
        val nearestName: String?,
        val distanceMeters: Float,
        val directionFromTrusted: String
    )

    /**
     * Mencari lokasi terpercaya terdekat dari posisi saat ini, lalu menentukan
     * apakah perangkat masih berada dalam radius zona terpercaya atau sudah
     * keluar (dan seberapa jauh + arahnya, dihitung DARI lokasi terpercaya
     * MENUJU posisi perangkat saat ini).
     */
    private fun evaluateTrustedZone(current: Location): ZoneInfo {
        val places = Prefs.getTrustedPlaces(this)
        if (places.isEmpty()) {
            return ZoneInfo(insideZone = false, nearestName = null, distanceMeters = 0f, directionFromTrusted = "-")
        }

        var nearest: TrustedPlace? = null
        var nearestDistance = Float.MAX_VALUE

        places.forEach { place ->
            val placeLoc = Location("trusted").apply {
                latitude = place.lat
                longitude = place.lon
            }
            val d = placeLoc.distanceTo(current)
            if (d < nearestDistance) {
                nearestDistance = d
                nearest = place
            }
        }

        val zoneRadius = Prefs.getZoneRadiusMeters(this)
        val insideZone = nearestDistance <= zoneRadius

        val direction = if (nearest != null) {
            val placeLoc = Location("trusted").apply {
                latitude = nearest!!.lat
                longitude = nearest!!.lon
            }
            bearingToDirection(placeLoc.bearingTo(current))
        } else {
            "-"
        }

        return ZoneInfo(
            insideZone = insideZone,
            nearestName = nearest?.name,
            distanceMeters = nearestDistance,
            directionFromTrusted = direction
        )
    }

    private fun describeFailedCount(count: Int): String = when (count) {
        0 -> "nihil"
        1 -> "sekali, status gagal"
        else -> "$count kali, status gagal"
    }

    private fun reverseGeocode(lat: Double, lon: Double): String {
        return try {
            val geocoder = Geocoder(this, Locale("id", "ID"))
            @Suppress("DEPRECATION")
            val results: List<Address>? = geocoder.getFromLocation(lat, lon, 1)
            val addr = results?.firstOrNull()
            if (addr != null) {
                listOfNotNull(
                    addr.thoroughfare,
                    addr.subLocality,
                    addr.locality,
                    addr.subAdminArea
                ).joinToString(", ").ifBlank { "alamat tidak diketahui" }
            } else {
                "alamat tidak diketahui"
            }
        } catch (e: Exception) {
            "alamat tidak tersedia (tanpa koneksi)"
        }
    }

    private data class WeatherInfo(
        val condition: String,
        val tempC: Double,
        val windSpeed: Double,
        val humidity: Int
    )

    private fun fetchWeather(lat: Double, lon: Double): WeatherInfo {
        return try {
            val url = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
                "&current=temperature_2m,relative_humidity_2m,wind_speed_10m,weather_code"
            val req = Request.Builder().url(url).get().build()
            httpClient.newCall(req).execute().use { resp ->
                val body = resp.body?.string() ?: return WeatherInfo("tidak diketahui", 0.0, 0.0, 0)
                val json = JSONObject(body)
                val current = json.getJSONObject("current")
                val code = current.getInt("weather_code")
                WeatherInfo(
                    condition = weatherCodeToText(code),
                    tempC = current.getDouble("temperature_2m"),
                    windSpeed = current.getDouble("wind_speed_10m"),
                    humidity = current.getInt("relative_humidity_2m")
                )
            }
        } catch (e: Exception) {
            WeatherInfo("tidak tersedia", 0.0, 0.0, 0)
        }
    }

    private fun weatherCodeToText(code: Int): String = when (code) {
        0 -> "cerah"
        1, 2 -> "cerah berawan"
        3 -> "berawan"
        45, 48 -> "berkabut"
        51, 53, 55, 56, 57 -> "gerimis"
        61, 63, 65, 66, 67 -> "hujan"
        71, 73, 75, 77 -> "hujan salju"
        80, 81, 82 -> "hujan lebat"
        95, 96, 99 -> "badai petir"
        else -> "tidak diketahui"
    }

    private data class BatteryInfo(val level: Int, val temperature: Double)

    private fun getBatteryInfo(): BatteryInfo {
        val intent = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val pct = if (level >= 0 && scale > 0) (level * 100 / scale) else -1
        val tempTenths = intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0
        return BatteryInfo(pct, tempTenths / 10.0)
    }

    private fun speak(text: String) {
        if (ttsReady) {
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "geomonitor_utterance")
        }
    }

    private fun sendToServer(
        location: Location,
        distance: Float,
        direction: String,
        address: String,
        weather: WeatherInfo,
        battery: BatteryInfo,
        screenLocked: Boolean,
        failedUnlockCount: Int,
        zoneInfo: ZoneInfo
    ) {
        val serverUrl = Prefs.getServerUrl(this)
        if (serverUrl.isBlank()) return

        try {
            val json = JSONObject().apply {
                put("device_token", Prefs.getDeviceToken(this@GeoMonitorService))
                put("timestamp", System.currentTimeMillis())
                put("latitude", location.latitude)
                put("longitude", location.longitude)
                put("altitude", if (location.hasAltitude()) location.altitude else JSONObject.NULL)
                put("distance_moved_m", distance)
                put("direction", direction)
                put("address", address)
                put("weather_condition", weather.condition)
                put("temperature_c", weather.tempC)
                put("wind_speed_kmh", weather.windSpeed)
                put("humidity_percent", weather.humidity)
                put("battery_percent", battery.level)
                put("device_temperature_c", battery.temperature)
                put("screen_locked", screenLocked)
                put("failed_unlock_count", failedUnlockCount)
                put("inside_trusted_zone", zoneInfo.insideZone)
                put("nearest_trusted_name", zoneInfo.nearestName ?: JSONObject.NULL)
                put("distance_from_trusted_m", zoneInfo.distanceMeters)
                put("direction_from_trusted", zoneInfo.directionFromTrusted)
            }

            val body = json.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
            val request = Request.Builder().url(serverUrl).post(body).build()
            httpClient.newCall(request).execute().close()
        } catch (e: Exception) {
            // Gagal kirim tidak boleh menghentikan monitoring; cukup diabaikan/dicatat lokal.
        }
    }

    /**
     * Kirim pesan ke WhatsApp lewat gateway pihak ketiga (contoh: Fonnte,
     * https://fonnte.com). Token & nomor tujuan diatur di layar pengaturan.
     * Format ini memakai gaya API Fonnte (POST form-data dengan header
     * Authorization berisi token). Kalau kamu memakai gateway lain, sesuaikan
     * URL dan nama field di bawah ini.
     */
    private fun sendWhatsApp(message: String) {
        val token = Prefs.getWhatsappToken(this)
        val number = Prefs.getWhatsappNumber(this)
        if (token.isBlank() || number.isBlank()) return

        try {
            val formBody = okhttp3.FormBody.Builder()
                .add("target", number)
                .add("message", message)
                .build()

            val request = Request.Builder()
                .url("https://api.fonnte.com/send")
                .addHeader("Authorization", token)
                .post(formBody)
                .build()

            httpClient.newCall(request).execute().close()
        } catch (e: Exception) {
            // Gagal kirim WhatsApp tidak boleh menghentikan monitoring.
        }
    }

    // ---------- Kamera: foto saat percobaan buka kunci gagal ----------

    private fun capturePhotoOnFailedUnlock(count: Int) {
        if (!Prefs.isCameraCaptureEnabled(this)) return
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            != PackageManager.PERMISSION_GRANTED
        ) return

        // Implementasi penuh CameraX ImageCapture memerlukan ProcessCameraProvider
        // yang di-bind ke lifecycle service ini (lihat CameraCaptureHelper.kt).
        CameraCaptureHelper.captureFrontPhoto(this) { success, filePath ->
            sendWhatsApp(
                "Peringatan: percobaan buka kunci layar gagal ke-$count pada perangkat anda. " +
                    "Status foto kamera depan: ${if (success) "sukses" else "gagal"}."
            )

            val serverUrl = Prefs.getServerUrl(this)
            if (serverUrl.isBlank()) return@captureFrontPhoto
            try {
                val json = JSONObject().apply {
                    put("device_token", Prefs.getDeviceToken(this@GeoMonitorService))
                    put("event", "failed_unlock_attempt")
                    put("attempt_count", count)
                    put("capture_status", if (success) "sukses" else "gagal")
                    put("timestamp", System.currentTimeMillis())
                    put("photo_path", filePath ?: "")
                }
                val body = json.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
                val request = Request.Builder().url(serverUrl).post(body).build()
                httpClient.newCall(request).execute().close()
            } catch (e: Exception) {
                // diabaikan
            }
        }
    }

    // ---------- Notifikasi foreground ----------

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Pemantauan Lokasi",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(content: String): Notification {
        val openIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("GeoMonitor aktif")
            .setContentText(content)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(content: String) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIF_ID, buildNotification(content))
    }
}
