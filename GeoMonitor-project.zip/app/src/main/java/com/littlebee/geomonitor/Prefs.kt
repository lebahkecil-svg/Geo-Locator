package com.littlebee.geomonitor

import android.content.Context

object Prefs {
    private const val NAME = "geomonitor_prefs"

    fun get(context: Context) = context.getSharedPreferences(NAME, Context.MODE_PRIVATE)

    fun isMonitoringEnabled(context: Context): Boolean =
        get(context).getBoolean("monitoring_enabled", false)

    fun setMonitoringEnabled(context: Context, value: Boolean) {
        get(context).edit().putBoolean("monitoring_enabled", value).apply()
    }

    fun getIntervalMinutes(context: Context): Int =
        get(context).getInt("interval_minutes", 1)

    fun setIntervalMinutes(context: Context, value: Int) {
        get(context).edit().putInt("interval_minutes", value).apply()
    }

    fun getMinDistanceMeters(context: Context): Float =
        get(context).getFloat("min_distance_meters", 10f)

    fun setMinDistanceMeters(context: Context, value: Float) {
        get(context).edit().putFloat("min_distance_meters", value).apply()
    }

    fun getServerUrl(context: Context): String =
        get(context).getString("server_url", "") ?: ""

    fun setServerUrl(context: Context, value: String) {
        get(context).edit().putString("server_url", value).apply()
    }

    fun getDeviceToken(context: Context): String =
        get(context).getString("device_token", "YMxcD0097") ?: "YMxcD0097"

    fun setDeviceToken(context: Context, value: String) {
        get(context).edit().putString("device_token", value).apply()
    }

    fun getLastLat(context: Context): Double =
        get(context).getFloat("last_lat", 0f).toDouble()

    fun getLastLon(context: Context): Double =
        get(context).getFloat("last_lon", 0f).toDouble()

    fun setLastLocation(context: Context, lat: Double, lon: Double) {
        get(context).edit()
            .putFloat("last_lat", lat.toFloat())
            .putFloat("last_lon", lon.toFloat())
            .apply()
    }

    fun hasLastLocation(context: Context): Boolean =
        get(context).contains("last_lat")

    fun getFailedUnlockCount(context: Context): Int =
        get(context).getInt("failed_unlock_count", 0)

    fun incrementFailedUnlockCount(context: Context): Int {
        val next = getFailedUnlockCount(context) + 1
        get(context).edit().putInt("failed_unlock_count", next).apply()
        return next
    }

    fun resetFailedUnlockCount(context: Context) {
        get(context).edit().putInt("failed_unlock_count", 0).apply()
    }

    fun isCameraCaptureEnabled(context: Context): Boolean =
        get(context).getBoolean("camera_capture_enabled", false)

    fun setCameraCaptureEnabled(context: Context, value: Boolean) {
        get(context).edit().putBoolean("camera_capture_enabled", value).apply()
    }

    // ---------- Lokasi Terpercaya ----------

    fun getTrustedPlaces(context: Context): List<TrustedPlace> =
        TrustedPlaceSerializer.fromJson(get(context).getString("trusted_places", null))

    fun setTrustedPlaces(context: Context, places: List<TrustedPlace>) {
        get(context).edit().putString("trusted_places", TrustedPlaceSerializer.toJson(places)).apply()
    }

    fun getZoneRadiusMeters(context: Context): Float =
        get(context).getFloat("zone_radius_meters", 150f)

    fun setZoneRadiusMeters(context: Context, value: Float) {
        get(context).edit().putFloat("zone_radius_meters", value).apply()
    }

    // ---------- WhatsApp ----------

    fun getWhatsappToken(context: Context): String =
        get(context).getString("whatsapp_token", "") ?: ""

    fun setWhatsappToken(context: Context, value: String) {
        get(context).edit().putString("whatsapp_token", value).apply()
    }

    fun getWhatsappNumber(context: Context): String =
        get(context).getString("whatsapp_number", "") ?: ""

    fun setWhatsappNumber(context: Context, value: String) {
        get(context).edit().putString("whatsapp_number", value).apply()
    }
}
