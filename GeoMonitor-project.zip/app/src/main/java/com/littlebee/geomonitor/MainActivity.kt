package com.littlebee.geomonitor

import android.Manifest
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.littlebee.geomonitor.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val permissionLauncher = registerForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val allGranted = results.values.all { it }
        if (!allGranted) {
            Toast.makeText(this, "Beberapa izin ditolak, fitur terkait tidak akan berfungsi", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        loadPrefsToUi()

        binding.switchMonitoring.setOnCheckedChangeListener { _, isChecked ->
            Prefs.setMonitoringEnabled(this, isChecked)
            if (isChecked) {
                requestNeededPermissions()
                startMonitoringService()
            } else {
                stopMonitoringService()
            }
        }

        binding.btnSaveSettings.setOnClickListener {
            saveUiToPrefs()
            Toast.makeText(this, "Pengaturan disimpan", Toast.LENGTH_SHORT).show()
            if (Prefs.isMonitoringEnabled(this)) {
                stopMonitoringService()
                startMonitoringService()
            }
        }

        binding.switchCamera.setOnCheckedChangeListener { _, isChecked ->
            Prefs.setCameraCaptureEnabled(this, isChecked)
            if (isChecked) {
                requestDeviceAdmin()
            }
        }

        binding.btnRequestPermissions.setOnClickListener {
            requestNeededPermissions()
        }
    }

    private fun loadPrefsToUi() {
        binding.switchMonitoring.isChecked = Prefs.isMonitoringEnabled(this)
        binding.editInterval.setText(Prefs.getIntervalMinutes(this).toString())
        binding.editMinDistance.setText(Prefs.getMinDistanceMeters(this).toInt().toString())
        binding.editServerUrl.setText(Prefs.getServerUrl(this))
        binding.editDeviceToken.setText(Prefs.getDeviceToken(this))
        binding.switchCamera.isChecked = Prefs.isCameraCaptureEnabled(this)
    }

    private fun saveUiToPrefs() {
        val interval = binding.editInterval.text.toString().toIntOrNull() ?: 1
        val minDistance = binding.editMinDistance.text.toString().toFloatOrNull() ?: 10f
        val serverUrl = binding.editServerUrl.text.toString().trim()
        val token = binding.editDeviceToken.text.toString().trim()

        Prefs.setIntervalMinutes(this, interval.coerceAtLeast(1))
        Prefs.setMinDistanceMeters(this, minDistance.coerceAtLeast(1f))
        Prefs.setServerUrl(this, serverUrl)
        Prefs.setDeviceToken(this, token.ifBlank { "YMxcD0097" })
    }

    private fun startMonitoringService() {
        val intent = Intent(this, GeoMonitorService::class.java)
        ContextCompat.startForegroundService(this, intent)
    }

    private fun stopMonitoringService() {
        val intent = Intent(this, GeoMonitorService::class.java)
        stopService(intent)
    }

    private fun requestNeededPermissions() {
        val permissions = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.CAMERA
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            permissions.add(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        val needed = permissions.filter {
            ActivityCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (needed.isNotEmpty()) {
            permissionLauncher.launch(needed.toTypedArray())
        }
    }

    private fun requestDeviceAdmin() {
        val compName = ComponentName(this, ScreenAdminReceiver::class.java)
        val dpm = getSystemService(DEVICE_POLICY_SERVICE) as DevicePolicyManager
        if (!dpm.isAdminActive(compName)) {
            val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, compName)
                putExtra(
                    DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                    "Diperlukan untuk mendeteksi percobaan buka kunci layar yang gagal."
                )
            }
            startActivity(intent)
        }
    }
}
