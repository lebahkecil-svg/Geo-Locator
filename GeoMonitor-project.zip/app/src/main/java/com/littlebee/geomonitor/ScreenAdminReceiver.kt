package com.littlebee.geomonitor

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent

/**
 * Device Admin receiver. Dengan ini aktif, sistem Android memanggil
 * onPasswordFailed() setiap kali pengguna salah memasukkan PIN/pola/password
 * di layar kunci. Dipakai untuk mendeteksi percobaan buka kunci yang gagal.
 *
 * Catatan: ini HANYA mendeteksi gagal input kredensial (PIN/pola/password),
 * bukan deteksi wajah/sidik jari biometrik yang gagal (keterbatasan API Android).
 */
class ScreenAdminReceiver : DeviceAdminReceiver() {

    override fun onPasswordFailed(context: Context, intent: Intent) {
        super.onPasswordFailed(context, intent)
        val count = Prefs.incrementFailedUnlockCount(context)

        val serviceIntent = Intent(context, GeoMonitorService::class.java)
        serviceIntent.action = GeoMonitorService.ACTION_UNLOCK_ATTEMPT_FAILED
        serviceIntent.putExtra(GeoMonitorService.EXTRA_FAILED_COUNT, count)
        context.startService(serviceIntent)
    }

    override fun onPasswordSucceeded(context: Context, intent: Intent) {
        super.onPasswordSucceeded(context, intent)
        // Reset hitungan setelah berhasil membuka kunci dengan benar.
        Prefs.resetFailedUnlockCount(context)
    }
}
