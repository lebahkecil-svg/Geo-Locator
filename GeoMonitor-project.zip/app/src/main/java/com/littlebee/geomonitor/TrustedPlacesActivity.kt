package com.littlebee.geomonitor

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class TrustedPlacesActivity : AppCompatActivity() {

    private lateinit var container: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_trusted_places)

        container = findViewById(R.id.containerLokasi)

        val existing = Prefs.getTrustedPlaces(this)
        if (existing.isEmpty()) {
            // Minimal 4 baris kosong untuk memudahkan pengisian pertama kali.
            repeat(4) { addRow(null) }
        } else {
            existing.forEach { addRow(it) }
        }

        findViewById<Button>(R.id.btnTambahLokasi).setOnClickListener {
            addRow(null)
        }

        findViewById<Button>(R.id.btnSimpanLokasi).setOnClickListener {
            saveAll()
        }
    }

    private fun addRow(place: TrustedPlace?) {
        val row = LayoutInflater.from(this).inflate(R.layout.item_trusted_place, container, false)
        row.findViewById<EditText>(R.id.editNama).setText(place?.name ?: "")
        row.findViewById<EditText>(R.id.editLat).setText(place?.lat?.toString() ?: "")
        row.findViewById<EditText>(R.id.editLon).setText(place?.lon?.toString() ?: "")
        row.findViewById<Button>(R.id.btnHapusLokasi).setOnClickListener {
            container.removeView(row)
        }
        container.addView(row)
    }

    private fun saveAll() {
        val places = mutableListOf<TrustedPlace>()
        for (i in 0 until container.childCount) {
            val row = container.getChildAt(i)
            val name = row.findViewById<EditText>(R.id.editNama).text.toString().trim()
            val lat = row.findViewById<EditText>(R.id.editLat).text.toString().trim().toDoubleOrNull()
            val lon = row.findViewById<EditText>(R.id.editLon).text.toString().trim().toDoubleOrNull()
            if (name.isNotBlank() && lat != null && lon != null) {
                places.add(TrustedPlace(name, lat, lon))
            }
        }

        if (places.size < 4) {
            Toast.makeText(
                this,
                "Disarankan minimal 4 lokasi terpercaya (saat ini: ${places.size}). Tetap disimpan.",
                Toast.LENGTH_LONG
            ).show()
        }

        Prefs.setTrustedPlaces(this, places)
        Toast.makeText(this, "${places.size} lokasi terpercaya disimpan", Toast.LENGTH_SHORT).show()
        finish()
    }
}
