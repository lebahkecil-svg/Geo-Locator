package com.littlebee.geomonitor

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.provider.MediaStore
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import java.text.SimpleDateFormat
import java.util.Locale

/**
 * Helper sederhana untuk mengambil satu foto dari kamera depan memakai CameraX,
 * dipanggil dari GeoMonitorService (yang merupakan LifecycleService) saat
 * terdeteksi percobaan buka kunci layar yang gagal.
 *
 * Foto disimpan ke galeri perangkat sendiri (MediaStore) folder "GeoMonitor".
 */
object CameraCaptureHelper {

    fun captureFrontPhoto(service: LifecycleService, onResult: (success: Boolean, path: String?) -> Unit) {
        val context = service as Context
        val providerFuture = ProcessCameraProvider.getInstance(context)

        providerFuture.addListener({
            try {
                val provider = providerFuture.get()
                val imageCapture = ImageCapture.Builder().build()
                val selector = CameraSelector.DEFAULT_FRONT_CAMERA

                provider.unbindAll()
                provider.bindToLifecycle(service, selector, imageCapture)

                val name = "GeoMonitor_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(System.currentTimeMillis())}.jpg"
                val contentValues = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                    put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/GeoMonitor")
                    }
                }

                val outputOptions = ImageCapture.OutputFileOptions.Builder(
                    context.contentResolver,
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                    contentValues
                ).build()

                imageCapture.takePicture(
                    outputOptions,
                    ContextCompat.getMainExecutor(context),
                    object : ImageCapture.OnImageSavedCallback {
                        override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                            provider.unbindAll()
                            onResult(true, output.savedUri?.toString())
                        }

                        override fun onError(exception: ImageCaptureException) {
                            provider.unbindAll()
                            onResult(false, null)
                        }
                    }
                )
            } catch (e: Exception) {
                onResult(false, null)
            }
        }, ContextCompat.getMainExecutor(context))
    }
}
