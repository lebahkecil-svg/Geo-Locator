package com.littlebee.geomonitor

import org.json.JSONArray
import org.json.JSONObject

data class TrustedPlace(
    val name: String,
    val lat: Double,
    val lon: Double
)

object TrustedPlaceSerializer {

    fun toJson(places: List<TrustedPlace>): String {
        val arr = JSONArray()
        places.forEach { place ->
            val obj = JSONObject()
            obj.put("name", place.name)
            obj.put("lat", place.lat)
            obj.put("lon", place.lon)
            arr.put(obj)
        }
        return arr.toString()
    }

    fun fromJson(json: String?): List<TrustedPlace> {
        if (json.isNullOrBlank()) return emptyList()
        return try {
            val arr = JSONArray(json)
            val result = mutableListOf<TrustedPlace>()
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                result.add(
                    TrustedPlace(
                        name = obj.optString("name", "Lokasi ${i + 1}"),
                        lat = obj.optDouble("lat", 0.0),
                        lon = obj.optDouble("lon", 0.0)
                    )
                )
            }
            result
        } catch (e: Exception) {
            emptyList()
        }
    }
}
