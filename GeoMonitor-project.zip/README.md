# GeoMonitor (Littlebee)

Aplikasi Android native (Kotlin) untuk memantau posisi perangkat sendiri:
- Notifikasi suara (TTS) saat perangkat berpindah ≥ jarak tertentu (default 10 meter)
- **Alamat Terpercaya**: atur minimal 4 lokasi (nama + koordinat) lewat menu "Kelola Alamat Terpercaya"
- Kalau perangkat **berada dalam radius zona terpercaya** (diatur sendiri, default 150 meter): notifikasi singkat "dalam zona terpercaya"
- Kalau perangkat **keluar dari semua zona terpercaya**: notifikasi lengkap jarak (km) & arah mata angin dari lokasi terpercaya terdekat
- Info koordinat, ketinggian, cuaca, kecepatan angin, **kelembaban**, alamat perkiraan
- Info baterai, suhu perangkat, status layar kunci, jumlah percobaan buka kunci gagal
- Deteksi percobaan buka kunci gagal + foto kamera depan (opsional, perlu izin Device Admin)
- Kirim semua data ke **server sendiri** (URL & token diatur di aplikasi) DAN ke **WhatsApp** (lewat gateway pihak ketiga seperti Fonnte)
- Interval pengecekan & aktif/non-aktif bisa diatur dari layar utama

## Cara build lewat GitHub (dari HP, pakai Chrome)

1. Buat repository baru di GitHub (public atau private).
2. Upload semua isi file zip ini ke repo (bisa lewat "Add file > Upload files" di web GitHub, drag semua folder/file hasil ekstrak zip).
3. Pastikan struktur folder di repo persis seperti ini:
   ```
   .github/workflows/build.yml
   app/
   build.gradle
   settings.gradle
   gradle.properties
   README.md
   ```
4. Setelah ter-upload dan ter-commit ke branch `main`, buka tab **Actions** di repo GitHub.
5. Workflow "Build APK" akan otomatis jalan (atau klik "Run workflow" manual).
6. Tunggu sampai selesai (centang hijau), lalu buka hasil run tersebut.
7. Scroll ke bagian **Artifacts**, unduh `GeoMonitor-debug-apk.zip` — di dalamnya ada `app-debug.apk`.
8. Install APK tersebut di HP (aktifkan "izinkan dari sumber tidak dikenal" kalau diminta).

## Setelah install

1. Buka aplikasi GeoMonitor.
2. Tekan **"Kelola Alamat Terpercaya"**, isi minimal 4 lokasi: nama (misal "Rumah", "Kantor") dan koordinatnya.
   - Cara dapat koordinat: buka Google Maps, tahan (tap & hold) di titik lokasi sampai muncul pin merah, koordinat (lat, lon) muncul di kotak pencarian atas — salin angkanya ke form Latitude/Longitude.
   - Tekan **Simpan Semua Lokasi**.
3. Kembali ke layar utama, isi **Radius zona terpercaya (meter)** — ini menentukan seberapa dekat dianggap "masih di zona aman" (default 150 meter).
4. Isi **URL Server** tujuan (server milik kamu sendiri) dan **Token/ID perangkat** (default: `YMxcD0097`, bisa diganti).
5. Isi **Token API WhatsApp gateway** dan **Nomor WhatsApp tujuan** (lihat bagian "Setup WhatsApp" di bawah).
6. Atur interval pengecekan (menit) dan jarak minimal pemberitahuan (meter).
7. Tekan **Minta Izin Lokasi & Kamera**, izinkan semua.
8. Buka Pengaturan > Aplikasi > GeoMonitor > Izin > Lokasi, pilih **"Izinkan setiap saat"** (wajib untuk latar belakang).
9. Kalau mau fitur foto kamera saat gagal buka kunci, aktifkan toggle **"Aktifkan foto kamera depan..."**, lalu setujui sebagai Device Admin saat diminta.
10. Nyalakan toggle **Aktifkan Pemantauan** di layar utama.

## Setup WhatsApp (via Fonnte, gratis untuk uji coba)

1. Buka [fonnte.com](https://fonnte.com), daftar akun.
2. Hubungkan nomor WhatsApp kamu sendiri sebagai "device" di dashboard Fonnte (scan QR, sama seperti WhatsApp Web).
3. Salin **Token** yang diberikan Fonnte di dashboard.
4. Paste token itu ke kolom **"Token API WhatsApp gateway"** di aplikasi.
5. Isi **"Nomor WhatsApp tujuan"** dengan nomor yang mau menerima notifikasi (format: `62xxxxxxxxxx`, tanpa tanda + atau spasi).
6. Kalau kamu pakai gateway lain (Wablas, WA Business API resmi, dll), beri tahu saya format API-nya — nanti saya sesuaikan kode `sendWhatsApp()` di `GeoMonitorService.kt`.

## Format server (JSON yang dikirim)

Aplikasi mengirim POST JSON ke URL server berisi: `device_token`, `timestamp`, `latitude`, `longitude`,
`altitude`, `distance_moved_m`, `direction`, `address`, `weather_condition`, `temperature_c`,
`wind_speed_kmh`, `battery_percent`, `device_temperature_c`, `screen_locked`, `failed_unlock_count`.
Sesuaikan endpoint di servermu untuk menerima format ini.

## Catatan penting

- Aplikasi ini dirancang untuk **dipakai sendiri** di perangkat sendiri (self-monitoring/anti-maling pribadi).
- Deteksi "percobaan buka kunci gagal" hanya berlaku untuk PIN/pola/password (keterbatasan API Android),
  bukan kegagalan sidik jari/wajah.
- Cuaca memakai API gratis Open-Meteo (tanpa API key, perlu koneksi internet).
- Pastikan server tujuan memakai HTTPS yang valid untuk keamanan data lokasi kamu.
